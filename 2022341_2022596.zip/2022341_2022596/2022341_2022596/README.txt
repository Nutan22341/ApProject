1. The Java Class and Method Declarations are in the directory: /src/main/java/com/example/javafx/
2. The skeleton screens with GUI components are in the directory: /src/main/resources/com/example/javafx/
   The Three FXML files are the GUI components : Scene1.fxml , Scene2.fxml , Scene3.fxml.
3. The Main class is: StickHero_Game.java
4. UML Class Diagram and Use case diagram are in their respective .pdf files
   Class Diagram: 2022341_2022596_ClassDiagram.pdf
   Use Case Diagram: 2022341_2022596_UseCaseDiagram.pdf
5. Assets used in this game are sourced from the internet and AI-generated images.
   We want to acknowledge and give credit to the original creators and the AI algorithms responsible for generating the images. 
   These assets are not owned by us, and we express gratitude for the creativity and contributions of the respective creators and technologies involved.
   


Group Number: 60

Name of Member1: Nutan kumari
	Roll No.: 2022341

Name of Member2: Vipul Sharma
	Roll No.: 2022596


