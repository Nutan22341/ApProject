package com.example.javafx;

public interface Initializable {
    public void initialize();
}
