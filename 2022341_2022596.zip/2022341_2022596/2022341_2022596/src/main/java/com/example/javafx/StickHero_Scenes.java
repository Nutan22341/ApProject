package com.example.javafx;

public class StickHero_Scenes {
    private void drawEntity(GameEntity entity) {
        // Draw the entity on the screen
        // You can use entity.imageView for rendering
    }

    // Method to draw a specific reward entity
    public void drawReward(Reward reward) {
        // Draw the reward on the screen
        drawEntity(reward);
    }

    public void draw_Player(Stickman player) {
    }

    public void draw_Platform() {
    }
}
