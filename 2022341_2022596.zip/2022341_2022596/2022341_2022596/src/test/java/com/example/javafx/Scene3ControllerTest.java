package com.example.javafx;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Scene3ControllerTest {

    @Test
    void backToHome() {
    }

    @Test
    void restart() {
    }
}